package com.example.FlightBookingAPIGatway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightBookingApiGatwayApplicationTests {

	@Test
	void contextLoads() {
	}

}
