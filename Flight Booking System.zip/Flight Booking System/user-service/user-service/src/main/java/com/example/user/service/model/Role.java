package com.example.user.service.model;

public enum Role {
    ADMIN, USER
}
