package com.paymentgateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StripePaymentGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
